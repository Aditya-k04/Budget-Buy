import Admin from "layouts/Admin/Admin";
import React, { useState, useEffect, useRef } from "react";
import { Link, useHistory, useLocation } from "react-router-dom";

// react plugin for creating notifications over the dashboard
import NotificationAlert from "react-notification-alert";

import {
  FormGroup,
  Label,
  Input,
  Button,
  Card,
  CardBody,
  Col,
  Alert
} from "reactstrap";

const Login = () => {
  const notificationAlertRef = useRef(null);
  const notify = (type,message) => {
    var options = {};
    options = {
      place: "tr",
      message: (
        <div>
          <div>
            <b>{message}</b>
          </div>
        </div>
      ),
      type: type,
      icon: "tim-icons icon-bell-55",
      autoDismiss: 3
    };
    notificationAlertRef.current.notificationAlert(options);
  };
  let history = useHistory();
  const location = useLocation();
  const [loginData, setLoginData] = useState({
    email: '',
    password: ''
  });

  const handleLoginData = (key, value) => {
    setLoginData({...loginData, [key]: value});
  }

  const handleLogin = () => {
    fetch(`/api/isExistUser`, {
      method: "POST",
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(loginData),
    })
    .then(response => response.json())
    .then(data => {
      console.log("data :: ",data);
      if(data?.userSession?.length > 0 && !data.userSession[0]?.is_admin && data.userSession[0]?.is_verified) {
        notify("success","Login Success!");
        sessionStorage.setItem("user_session", JSON.stringify({'id': data.userSession[0]?.id, 'email': data.userSession[0]?.email, 'first_name': data.userSession[0]?.first_name, 'last_name': data.userSession[0]?.last_name, 'is_admin': data.userSession[0]?.is_admin, 'is_verified': data.userSession[0]?.is_verified}));
        history.push('/students');
      } else {
        if(!data.userSession[0]?.is_verified){
          notify("danger","Your account is not verified yet! Please try again later");
        } else if(data.userSession[0]?.is_admin) {         
          notify("warning","Wrong User Credentials!"); 
        } else {
          notify("warning","Invalid Credentials!");
        }
      }
    });
  }

  return (
    <>
      <div className="react-notification-alert-container">
        <NotificationAlert ref={notificationAlertRef} />
      </div>
      <div className="loginFlexWrapper">        
        <Col lg="4" md="6" xs="12">
          <Card>
            <CardBody>
              <form onSubmit={e => {e.preventDefault();handleLogin();}}>
                <FormGroup>
                  <Label for="email">Email address</Label>
                  <Input
                    type="email"
                    name="email"
                    id="email"
                    placeholder="Enter email"
                    value={loginData.email}
                    onChange={(e) => handleLoginData(e.target.name, e.target.value)}
                    required
                  />
                </FormGroup>
                <FormGroup>
                  <Label for="password">Password</Label>
                  <Input
                    type="password"
                    name="password"
                    id="password"
                    placeholder="Password"
                    pattern="(?=[A-Za-z0-9@#$%^&+!=]+$)^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&+!=])(?=.{8,}).*$"
                    autoComplete="off"
                    value={loginData.password}
                    onChange={(e) => handleLoginData(e.target.name, e.target.value)}
                    title="At least 8 characters, min 1 Uppercase 1 Lowercase 1 Number 1 special character and only contains symbols from the alphabet, num"
                    required="At least 8 characters, min 1 Uppercase 1 Lowercase 1 Number 1 special character and only contains symbols from the alphabet, num"
                  />
                </FormGroup>
                <Button color="primary" type="submit">
                    Submit
                </Button>
              </form>
              <Link to="/register" onClick={() => <Admin />}>Not an account? Sign Up here</Link>
            </CardBody>
          </Card>
      </Col>
    </div>
    </>
  );
};

export default Login;
