import React, { useState, useRef, useEffect } from "react";
import { Link, useHistory } from "react-router-dom";

// react plugin for creating notifications over the dashboard
import NotificationAlert from "react-notification-alert";

import {
    Breadcrumb, 
    BreadcrumbItem,
    FormGroup,
    Label,
    Input,
    FormText,
    Button,
    Card,
    CardTitle,
    CardBody,
    CardImg,
    Row,
    Col,
    CardText,
    Container,
    CardFooter,
    Table
} from "reactstrap";

import MainCarousel from "components/Section/MainCarousel.js";
import { useLocation } from "react-router-dom";

const Orders = (props) => {  
    const userSession = JSON.parse(sessionStorage.getItem('user_session'));
    const location = useLocation();
    console.log("user session => ",userSession);
    const notificationAlertRef = useRef(null);
    const [orders, setOrders] = useState([]);
    const [ordersMounted, setOrdersMounted] = useState(false);

    const notify = (type,message) => {
        var options = {};
        options = {
            place: "tr",
            message: (
                <div>
                    <div>
                        <b>{message}</b>
                    </div>
                </div>
            ),
            type: type,
            icon: "tim-icons icon-bell-55",
            autoDismiss: 3
        };
        notificationAlertRef.current.notificationAlert(options);
    };

    const getOrders = async () => {        
        await fetch(`/api/get-orders?seller_id=${userSession?.id}`)
        .then(resp => resp.json())
        .then(result => {
            if (result?.length > 0) {
                setOrders(result);
            }
        });
    }

    useEffect(() => {
        getOrders();        
        setOrdersMounted(true)
    }, [!ordersMounted]);

    console.log(ordersMounted," orders >> ",orders);

    const handleOrderFulfill = async (orderId) => {
        await fetch('/api/fulfill-order',{
            method:"POST",
            headers: {
                'content-type':'application/json'
            },
            body: JSON.stringify({'order_id': orderId})
        }).then(resp => resp.json())
        .then(result => (result?.affectedRows) && setOrdersMounted(false),notify("success", "Orders updated!"))
    };

    const OrdersHead = (
        <thead>
            <tr>
                <th className="text-center">#</th>
                <th>Date</th>
                <th>Order Id</th>
                <th>User</th>
                <th>Contact No.</th>
                <th>Item name</th>
                <th>Price</th>
                <th className="text-right">Actions</th>
            </tr>
        </thead>
    );

    const OrdersBody =  ordersMounted && orders?.length > 0 && orders?.map((order, index) => {
        let dateObj = new Date(order.created_at);
        let currentDate = dateObj.getDay()+'-'+(dateObj.getMonth()+1)+'-'+dateObj.getFullYear();
        return (
            <tr>
                <td className="text-center">{index+1}</td>
                <td>{currentDate}</td>
                <td>{order.id}</td>
                <td>{order.first_name +' '+order.last_name}</td>
                <td>{order.phone}</td>
                <td>{order.product_name}</td>
                <td>{order.price}</td>
                <td className="text-right">
                    <Button className="btn-icon w-100" color={(order.fulfillment_status)?'success':'danger'} onClick={() => handleOrderFulfill(order.id)} disabled={(order.fulfillment_status)?true:false}>
                        {(order.fulfillment_status)?
                            'Fulfilled'
                            :
                            'Fulfill'
                        }
                    </Button>
                </td>
            </tr>
        )
    });

    const ordersTable = (
        <Table responsive>
            {OrdersHead}
            <tbody>
                {OrdersBody}
            </tbody>
        </Table>
    );

    return (
        <>
            {
                (ordersMounted)?
                <div className="content">
                    <div className="react-notification-alert-container">
                        <NotificationAlert ref={notificationAlertRef} />
                    </div>
                    <Row>
                        <Col>
                            <Card>
                                {(orders?.length > 0)?
                                <CardBody>
                                    {ordersTable}
                                </CardBody>
                                :
                                <CardBody>
                                    No orders found!
                                </CardBody>
                                }
                            </Card>
                        </Col>
                    </Row>
                </div>
                :
                <div className="content">
                    <div className="react-notification-alert-container">
                        <NotificationAlert ref={notificationAlertRef} />
                    </div>
                    <Row>
                        <Col>
                            <Card>
                                <CardBody>
                                    Loading orders
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                </div>
            }
        </>
    );
};

export default Orders;
