import React, { useState, useRef, useEffect } from "react";
import { Link, useHistory } from "react-router-dom";

// react plugin for creating notifications over the dashboard
import NotificationAlert from "react-notification-alert";

import {
  FormGroup,
  Label,
  Input,
  FormText,
  Button,
  Card,
  CardTitle,
  CardBody,
  CardImg,
  Row,
  Col,
  CardText,
  Container
} from "reactstrap";

import AddProducts from "components/Students/AddProducts.js";
import EditProducts from "components/Students/EditProducts.js";
import MainCarousel from "components/Section/MainCarousel.js";

const StudentProducts = () => {  
    const userSession = JSON.parse(sessionStorage.getItem('user_session'));
    const history = useHistory();
    const notificationAlertRef = useRef(null);
    const [productCurrentAction, setProductCUrrentAction] = useState('');
    const [allProducts, setAllProducts] = useState([]);
    const [allImages, setAllImages] = useState([]);
    const [allProductsLoaded, setAllProductsLoaded] = useState(false);
    
    const handleProductAction = (action) => {
        setProductCUrrentAction(action);
    };

    const notify = (type,message) => {
        var options = {};
        options = {
        place: "tr",
        message: (
            <div>
            <div>
                <b>{message}</b>
            </div>
            </div>
        ),
        type: type,
        icon: "tim-icons icon-bell-55",
        autoDismiss: 3
        };
        notificationAlertRef.current.notificationAlert(options);
    };

    useEffect(() => {
        fetch(`/api/get-all-student-products?id=${userSession.id}`)
        .then(resp => resp.json())
        .then(result => {
            setAllProducts(result);
            setAllProductsLoaded(true);
        });
    },[!allProductsLoaded]);

    const handleAllProductLoaded = (isLoaded) => {
        setAllProductsLoaded(isLoaded);
        if(isLoaded) {
            notify("info", "New Product Loaded!");
        }
    };

    const deleteCurrentProduct = (product_id) => {
        console.log("id >> ",product_id);
        fetch(`/api/delete-product`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({'product_id': product_id}),
        })
        .then(resp => resp.json())
        .then(result => {
            if(result.affectedRows) {
                setAllProductsLoaded(false);
                notify("success",'Selected Product Deleted!');
            }
        });
    }

    const ProductsBody =  allProductsLoaded && allProducts?.length > 0 && allProducts?.map((product,index) => {
        let dateObj = new Date(product.use_time);
        let dayVar = (dateObj.getDate() <= 9)?`0${dateObj.getDate()}`:dateObj.getDate();
        let monthVar = ((dateObj.getMonth()+1) <= 9)?`0${(dateObj.getMonth()+1)}`:(dateObj.getMonth()+1);
        let lastDate = `${dayVar}-${monthVar}-${dateObj.getFullYear()}`;
        const oneDay = 24 * 60 * 60 * 1000;
        const firstDate = new Date();
        const diffDays = Math.round(Math.abs((firstDate - dateObj) / oneDay));
        console.log("diffDays > ",diffDays);
        let product_images = [];
        product.images.split(",").map((name,index)=> {
            product_images.push({src: `/public/uploads/products/${name}`, altText: name.split(".")[0], key: index});
        });
        
        return (
        <>
            <Col key={index} className="col-lg-3">
                <Card>
                    {(product_images.length > 1)?
                    <MainCarousel slides={product_images} />
                    :
                    <CardImg src={`/public/uploads/products/${product.images.split(",")[0]}`} alt={product_images[0].altText} style={{'minHeight':'320px'}}></CardImg>
                    }                  
                    <CardBody>
                        <CardTitle tag="span">{product.tag}</CardTitle>
                        <CardTitle tag="h4">{product.title}</CardTitle>
                        <CardText>
                            <span>
                                {product.price}
                            </span>
                        </CardText>
                        <CardText>
                            {diffDays} days old
                        </CardText>                        
                        {(product.status === 0) ?
                        <Row>
                            <Col className="col-6">
                                <FormGroup>
                                    <Button title="Edit Product" onClick={() => setProductCUrrentAction(<EditProducts productData={product} handlerProductAction={handleProductAction} handlerAllProductsLoaded={handleAllProductLoaded} />)} className="actionBtns w-100" color="info"><i className="tim-icons icon-pencil" /></Button>
                                </FormGroup>
                            </Col>
                            <Col className="col-6">
                                <FormGroup>
                                    <Button title="Delete Product" onClick={() => deleteCurrentProduct(product.id)} className="actionBtns w-100" color="danger"><i className="tim-icons icon-trash-simple" /></Button>
                                </FormGroup>
                            </Col>
                        </Row>
                        :                        
                        <Row>
                            <Col className="col-6">
                                <FormGroup>
                                    <Button title="View Product" onClick={() => history.push("/students/view_product",{'current_product': product})} style={{'cursor':"pointer"}} className="actionBtns w-100" color="primary">View</Button>
                                </FormGroup>
                            </Col>
                        </Row>
                        }
                    </CardBody>
                </Card>
            </Col>
        </>
    )});

    return (
        <>
            {
                (productCurrentAction == '')?
                <div className="content">
                    <div className="react-notification-alert-container">
                        <NotificationAlert ref={notificationAlertRef} />
                    </div>
                    <div className="studentProductsFlexWrapper">          
                        <Row>
                            <Col xs="12">
                                <Card>
                                    <CardTitle className="pl-3 pr-3 mt-2 d-flex align-items-center justify-content-between" tag="h3">
                                        <span>Your Products</span>
                                        <Button onClick={() => setProductCUrrentAction(<AddProducts handlerProductAction={handleProductAction} handlerAllProductsLoaded={handleAllProductLoaded} />)}>Add Product</Button>
                                    </CardTitle>
                                    {(allProductsLoaded) && (
                                        <CardBody>
                                            <Container>
                                                <Row>
                                                    {ProductsBody}
                                                </Row>
                                            </Container>
                                        </CardBody>
                                    )}
                                </Card>
                            </Col>
                        </Row>                        
                    </div>
                </div>
                :
                <div className="content">
                    {productCurrentAction}
                </div>
            }
        </>
    );
};

export default StudentProducts;
