import React, { useState, useRef, useEffect } from "react";
import { Link, useHistory, useLocation } from "react-router-dom";

// react plugin for creating notifications over the dashboard
import NotificationAlert from "react-notification-alert";

import {
  FormGroup,
  Label,
  Input,
  FormText,
  Button,
  Card,
  CardBody,
  Col,
  Row,
  FormFeedback,
  Alert,
  CardImg,
  CardText,
  CardTitle,
  Form
} from "reactstrap";

import Login from "./Login.js";

const Register = () => {  
  const notificationAlertRef = useRef(null);
  const notify = (type,message) => {
    var options = {};
    options = {
      place: "tr",
      message: (
        <div>
          <div>
            <b>{message}</b>
          </div>
        </div>
      ),
      type: type,
      icon: "tim-icons icon-bell-55",
      autoDismiss: 3
    };
    notificationAlertRef.current.notificationAlert(options);
  };
  const history = useHistory();
  const location = useLocation();
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    contact_no: '',
    prn: '',
    doc: [],
    email: '',
    password: '',
    confirm_password: ''
  });
  const [isInvalid, setIsInvalid] = useState(false);
  const [isFileLoaded, setIsFileLoaded] = useState(true);
  console.log(history," location > ",location);

  useEffect(() => {
    if(location?.state?.length > 0 && location?.state[0]?.newUser) {      
      notify("success","User Registered!");  
      setTimeout(() => history.push("/login"), 1500);
    }
    setIsFileLoaded(true)
  },[!isFileLoaded, location?.state]);

  const handleFormData = (key, value) => {
    console.log(key," ::: ",value);
    if(key === 'doc') {
      console.log("doc > ",formData.doc.length);
      if(formData.doc.length > 0) {
        formData.doc[0] = value;
      } else {        
        formData.doc.push(value);
      }
      setFormData(formData);
      setIsFileLoaded(false);
    } else {
      setFormData({...formData, [key]:value});      
    }
  };

  const handleSubmitForm = async () => {
    if(formData.password === formData.confirm_password) {
      let form_data = new FormData();
      for (const doc of formData.doc) {
        console.log("document > ",doc);
          form_data.append('doc', doc) ;
      }
      form_data.append("reg_info",JSON.stringify(formData));
  
      const response = await fetch(`/api/insertUser`, {
        method: 'POST',
        body: form_data
      }).then(resp => resp.json());
      console.log("response > ",response);
      if(!response?.alreadyUser) {
        notify("success","User Registered!");             
        // sessionStorage.setItem("user_session", JSON.stringify({'id': data.userSession[0]?.id, 'email': data.userSession[0]?.email, 'first_name': data.userSession[0]?.first_name, 'last_name': data.userSession[0]?.last_name, 'is_admin': data.userSession[0]?.is_admin}));
        history.push('/register',[{'newUser': true}]);
      } else {
        notify("warning","User Exist!");
      }
      setIsInvalid(false);
      
    } else {
      notify("danger","Password Should be Match!");
      formData.confirm_password = '';
      console.log("form ::: ",formData);
      setIsInvalid(true);
    }
  }

  return (
    <>
      <div className="react-notification-alert-container">
        <NotificationAlert ref={notificationAlertRef} />
      </div>
      <div className="registerFlexWrapper">
          <Col lg="4" md="6" xs="12">
              <Card>
                  <CardBody>
                      <Form onSubmit={(e) => {e.preventDefault(); handleSubmitForm();}}>
                        <Row>
                          <FormGroup className="col-lg-6">
                              <Label for="first_name">First Name</Label>
                              <Input
                                  type="text"
                                  name="first_name"
                                  id="first_name"
                                  placeholder="Enter First Name"
                                  value={formData.first_name}
                                  onChange={(e) => handleFormData(e.target.name, e.target.value)}
                              />
                          </FormGroup>
                          <FormGroup className="col-lg-6">
                              <Label for="last_name">Last Name</Label>
                              <Input
                                  type="text"
                                  name="last_name"
                                  id="last_name"
                                  placeholder="Enter Last Name"
                                  value={formData.last_name}
                                  onChange={(e) => handleFormData(e.target.name, e.target.value)}
                              />
                          </FormGroup>
                        </Row>
                        <FormGroup>
                          <Label for="contact_no">Contact No.</Label>
                          <Input
                              type="tel"
                              name="contact_no"
                              id="contact_no"
                              placeholder="Enter Contact no. 10 digits long, and start with 7, 8, or 9"
                              value={formData.contact_no}
                              pattern="[7/8/9]{1}[0-9]{9}"
                              minLength={10}
                              maxLength={10}
                              onChange={(e) => handleFormData(e.target.name, e.target.value)}
                          />
                        </FormGroup>
                        <FormGroup>
                          <Label for="prn">PRN</Label>
                          <Input
                              type="text"
                              name="prn"
                              id="prn"
                              placeholder="Enter PRN"
                              value={formData.prn}
                              onChange={(e) => handleFormData(e.target.name, e.target.value)}
                              required
                          />
                        </FormGroup>
                        <FormGroup>
                            <Label style={{'display':'block', 'width':'100%'}}>Upload PRN / ID / Bonafied Document</Label>
                            <Label for="doc" style={{"cursor":"pointer"}}>                                
                            {(formData.doc.length > 0)?
                              <><CardTitle tag="span" className="mr-2">{formData.doc[0]?.name}</CardTitle><Button color="warning" size="sm">Change FIle</Button></>
                            :
                              <><CardTitle tag="span" className="mr-2">Student ID proof</CardTitle><Button size="sm" className="ml-2">Choose File</Button>                                  </>
                            }
                            </Label>
                            <Input
                                id="doc"
                                type="file"
                                name="doc"
                                onChange={(e) => handleFormData(e.target.name, e.target.files[0])}
                                style={{"cursor":"pointer"}}
                                title="Please choose file!"
                                required
                            />
                        </FormGroup>
                        <FormGroup>
                            <Label for="email">Email address</Label>
                            <Input
                            type="email"
                            name="email"
                            id="email"
                            placeholder="Enter email"
                            value={formData.email}
                            onChange={(e) => handleFormData(e.target.name, e.target.value)}
                            required
                            />
                            <FormText color="muted">
                                We'll never share your email with anyone else.
                            </FormText>
                        </FormGroup>
                        <FormGroup>
                            <Label for="password">Password</Label>
                            <Input
                            type="password"
                            name="password"
                            id="password"
                            placeholder="Enter password"
                            pattern="(?=[A-Za-z0-9@#$%^&+!=]+$)^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&+!=])(?=.{8,}).*$"
                            autoComplete="off"
                            value={formData.password}
                            onChange={(e) => handleFormData(e.target.name, e.target.value)}
                            minLength={8}
                            title="At least 8 characters, min 1 Uppercase 1 Lowercase 1 Number 1 special character and only contains symbols from the alphabet, num"
                            required="At least 8 characters, min 1 Uppercase 1 Lowercase 1 Number 1 special character and only contains symbols from the alphabet, num"
                            />
                        </FormGroup>
                        <FormGroup>
                            <Label for="confirm_password">Confirm Password</Label>
                            <Input
                            type="password"
                            name="confirm_password"
                            id="confirm_password"
                            placeholder="Confirm Password"
                            autoComplete="off"
                            pattern="(?=[A-Za-z0-9@#$%^&+!=]+$)^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&+!=])(?=.{8,}).*$"
                            value={formData.confirm_password}
                            onChange={(e) => handleFormData(e.target.name, e.target.value)}
                            minLength={8}
                            invalid={isInvalid}
                            title="At least 8 characters, min 1 Uppercase 1 Lowercase 1 Number 1 special character and only contains symbols from the alphabet, num"
                            required="At least 8 characters, min 1 Uppercase 1 Lowercase 1 Number 1 special character and only contains symbols from the alphabet, num"
                            />
                            {isInvalid && 
                              <FormFeedback>
                                Password do not match
                              </FormFeedback>
                            }
                        </FormGroup>
                        {/* <FormGroup check>
                          <Label check>
                            <Input type="checkbox" name="is_bonafied" checked={formData.is_bonafied} onChange={(e) => handleFormData(e.target.name, e.target.checked)} />{' '}
                            has Bonafied
                            <span className="form-check-sign">
                              <span className="check"></span>
                            </span>
                          </Label>
                        </FormGroup> */}
                        <Button color="primary" type="submit">Submit</Button>
                      </Form>
                      <Link to="/login" onClick={() => <Login />}>Already an account? Sign In here</Link>
                  </CardBody>
              </Card>
          </Col>
      </div>
    </>
  );
};

export default Register;
