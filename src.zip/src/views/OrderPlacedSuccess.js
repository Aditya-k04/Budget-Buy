import { 
    Container, 
    Row, 
    Col, 
    Table, 
    CardTitle,
    CardHeader,
    Card,
    CardBody,
    CardFooter, 
    Button,
    Badge,
    CardImg
 } from "reactstrap";
import React, { useEffect, useState } from "react";
import { useLocation, useHistory } from "react-router-dom";

const OrderPlacedSuccess = () => {
    const location = useLocation();
    const history = useHistory();
    const [isMounted, setIsMounted] = useState(false);
    console.log("location >> ",location);    

    useEffect(() => {
        setTimeout(() => setIsMounted(true), 7000);
    },[!isMounted]);


    return(
        <div className="content orderSuccessPage">
            <Container fluid>
                <Row>
                    <Col>
                        {(isMounted)?
                        <Card className="text-center w-100 align-items-center flex-row" style={{'minHeight':'95vh'}}>
                            <CardBody>
                                <CardHeader>
                                    <i className="tim-icons icon-check-2" style={{"fontSize":"86px"}}></i> 
                                    <CardTitle tag="h1">Your order has been placed!</CardTitle>
                                </CardHeader>
                                <CardFooter className="w-100">
                                    <Button color="success" onClick={() => history.push("/students/my-orders")}>
                                        Go to orders
                                    </Button>
                                </CardFooter>
                            </CardBody>
                        </Card>
                        :
                        <Card className="text-center align-items-center flex-row" style={{'minHeight':'95vh'}}>
                            <CardBody className="w-100">
                                <CardImg src={require('../assets/img/loading.gif')} style={{"maxWidth":"50%"}} />
                            </CardBody>
                        </Card>
                        }
                    </Col>
                </Row>
            </Container>
        </div>
    );
}

export default OrderPlacedSuccess;