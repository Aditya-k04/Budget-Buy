import React, { useState, useEffect, useRef } from "react";
import { useHistory, useLocation } from "react-router-dom";
// react plugin for creating notifications over the dashboard
import NotificationAlert from "react-notification-alert";

// reactstrap components
import {
    Badge,
  Button,
  FormGroup,
  Card,
  CardHeader,
  CardImg,
  CardText,
  CardBody,
  CardTitle,
  Row,
  Col,
  Container,
  Form,
  UncontrolledCollapse,
  Label,
  Input
} from "reactstrap";

import MainCarousel from "components/Section/MainCarousel.js";

function Dashboard(props) {
    const userSession = JSON.parse(sessionStorage.getItem('user_session'));
    console.log("userSession > ",userSession);
    const history = useHistory();
    const location = useLocation();
    const notificationAlertRef = useRef();
    const [allProducts, setAllProducts] = useState([]);
    const [productCategories, setProductCategories] = useState([]);
    const [categories, setCategories] = useState([]);
    const [filterTags, setFilterTags] = useState([]);
    const [productTags, setProductTags] = useState([]);
    const [allProductsLoaded, setAllProductsLoaded] = useState(false);
    const [allCategoriesLoaded, setAllCategoriesLoaded] = useState(false);
    
    const notify = (type,message) => {
        var options = {};
        options = {
            place: "tr",
            message: (
                <div>
                    <div>
                        <b>{message}</b>
                    </div>
                </div>
            ),
            type: type,
            icon: "tim-icons icon-bell-55",
            autoDismiss: 3
        };
        notificationAlertRef.current.notificationAlert(options);
    };

    const getPosts = async () => {
        await fetch(`/api/get-verified-students-products`)
        .then(resp => resp.json())
        .then(result => {
            setAllProducts(result);
            setAllProductsLoaded(true);
        });
    }

    const getCatgories = async () => {
        await fetch('/api/get-all-categories')
        .then(resp => resp.json())
        .then(result => {
            if(result.length > 0) {
                setProductCategories(result);
                setAllCategoriesLoaded(true);
            }
        });
    }

    useEffect(() => {
        getCatgories();
        getPosts();
    },[!allProductsLoaded]);  

    const ProductsBody =  allProductsLoaded && allProducts.length > 0 && allProducts.map((product,index) => {
        let dateObj = new Date(product?.use_time);
        let dayVar = (dateObj.getDate() <= 9)?`0${dateObj.getDate()}`:dateObj.getDate();
        let monthVar = ((dateObj.getMonth()+1) <= 9)?`0${(dateObj.getMonth()+1)}`:(dateObj.getMonth()+1);
        let lastDate = `${dayVar}-${monthVar}-${dateObj.getFullYear()}`;
        const oneDay = 24 * 60 * 60 * 1000;
        const firstDate = new Date();
        const diffDays = Math.round(Math.abs((firstDate - dateObj) / oneDay));
        let product_images = [];
        let product_tags = [];
        product?.images?.split(",").map((name,index)=> {
            product_images.push({src: `/public/uploads/products/${name}`, altText: name.split(".")[0], key: index});
        });
        product?.tags?.split(",").map((tag, index)=>{
            product_tags = [...product_tags, tag];
        });
        
        return (
        <>
            <Col key={index} className="col-lg-3">
                <Card>
                    {(product_images.length > 1)?
                    <MainCarousel slides={product_images} />
                    :
                    <CardImg src={product_images[0].src} alt={product_images[0].altText} style={{'minHeight':'320px'}}></CardImg>
                    }
                    <CardBody>
                        <CardTitle tag="span">{product.tag}</CardTitle>
                        <CardTitle tag="h4">{product.title}</CardTitle>
                        <CardText tag="div">
                            {diffDays} days old                            
                        </CardText>
                        <CardText className="mt-2" tag="div">
                            {product.price + `/-`}
                        </CardText>
                        <CardText>
                            {(product.status === 0)?<Badge color="primary">Active</Badge>:<Badge color="dark">Sold Out</Badge>}
                        </CardText>
                    </CardBody>
                </Card>
            </Col>
        </>
      )});
    
  
    return (
        <>
            <div className="content">
                <div className="react-notification-alert-container">
                    <NotificationAlert ref={notificationAlertRef} />
                </div>
                <Card>          
                    <Container>
                        <Row>
                            <Col xs="12">    
                                <CardHeader>
                                    <Container>
                                        <Row>
                                            <Col className="col-12 col-md-12 col-lg-12">
                                                <CardTitle className="mt-2" tag="h3">
                                                   All Current Posts
                                                </CardTitle>
                                            </Col>
                                        </Row>
                                    </Container>
                                </CardHeader>
                                {(allProductsLoaded) && (                                    
                                <CardBody>
                                    <Container>
                                        <Row>
                                            {ProductsBody}
                                        </Row>
                                    </Container>
                                </CardBody>
                                )}
                            </Col>
                        </Row>
                    </Container>
                </Card>
            </div>
        </>
    );
}

export default Dashboard;
