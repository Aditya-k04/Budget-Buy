import React, { useEffect, useState, useRef } from "react";

import NotificationAlert from "react-notification-alert";
// reactstrap components
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  CardText,
  FormGroup,
  Form,
  Input,
  Label,
  Row,
  Col,
  UncontrolledAlert,
  Spinner,
} from "reactstrap";

function UserProfile() {
  const userSession = JSON.parse(sessionStorage.getItem('user_session'));
  const [userProfileInfo, setUserProfileInfo] = useState({
    id: userSession.id,
    is_admin: userSession.is_admin,
    first_name: (userSession.first_name != null)?userSession.first_name:'',
    last_name: (userSession.last_name != null)?userSession.last_name:'',
    email: userSession.email,
    gender: '',
    address: '',
    landmark: '',
    city: '',
    state: '',
    pincode: '',
    contact_no: ''
  });
  const [isMounted, setIsMounted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const notificationAlertRef = useRef('');
  
  const notify = (type, place="tr", message) => {
    var options = {};
    options = {
      place: place,
      message: (
        <div>
          <div>
            <b>{message}</b>
          </div>
        </div>
      ),
      type: type,
      icon: "tim-icons icon-bell-55",
      autoDismiss: 3
    };
    notificationAlertRef.current.notificationAlert(options);
  };

  useEffect(() => {
    if(!userSession.is_admin){      
      fetch(`/api/get-user-profile?student_id=${userSession?.id}`)
      .then(resp => resp.json())
      .then(result => {
        if(result.length > 0) {
          setUserProfileInfo({...userProfileInfo, ["gender"]:(result[0].gender != null)?result[0].gender:'', ["address"]:(result[0].address != null)?result[0].address:'', ["landmark"]:(result[0].landmark != null)?result[0].landmark:'', ["city"]:(result[0].city != null)?result[0].city:'', ["state"]:(result[0].state != null)?result[0].state:'', ["pincode"]:(result[0].pincode != null)?result[0].pincode: '', ["contact_no"]:(result[0].phone != null)?result[0].phone:''});
          setIsMounted(true);
        }
      })
    } else {
      setIsMounted(true); 
    }
  }, [!isMounted]);

  const handleUpdateProfileData = (key, value) => {
    setUserProfileInfo({...userProfileInfo, [key]: value});
  }

  const submitProfileUpdateForm = () => {
    setIsLoading(true);
    console.log("profile updated :: ",userProfileInfo);
    fetch(`/api/updateUserProfile`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(userProfileInfo),
    })
    .then(resp => resp.json())
    .then(data => {
      console.log("data >>> ",data);
      if(data?.userSession?.length > 0) {
        sessionStorage.setItem("user_session", JSON.stringify({'id': data.userSession[0]?.id, 'email': data.userSession[0]?.email, 'first_name': data.userSession[0]?.first_name, 'last_name': data.userSession[0]?.last_name, 'is_admin': data.userSession[0]?.is_admin}));
        notify('success','tr','Profile has been updated!');
        setIsLoading(false);
      }
    });
  }

  return (
    <>
      <div className="content">
        <div className="react-notification-alert-container">
          <NotificationAlert ref={notificationAlertRef} />
        </div>
        <Row>
          <Col md="9">
            <Card>
              <CardHeader>
                <h5 className="title">Edit Profile</h5>
              </CardHeader>
              <CardBody>
                <Form onSubmit={(e) => e.preventDefault()}>
                  <Row>
                    <Col className="pr-md-1" md="6">
                      <FormGroup>
                        <label>First Name</label>
                        <Input
                          value={userProfileInfo.first_name}
                          placeholder="First Name"
                          type="text"
                          name="first_name"
                          onChange={(e) => handleUpdateProfileData(e.target.name, e.target.value)}
                        />
                      </FormGroup>
                    </Col>
                    <Col className="pl-md-1" md="6">
                      <FormGroup>
                        <label>Last Name</label>
                        <Input
                          value={userProfileInfo.last_name}
                          placeholder="Last Name"
                          name="last_name"
                          type="text"
                          onChange={(e) => handleUpdateProfileData(e.target.name, e.target.value)}
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col className="pr-md-1" md="6">
                      <FormGroup>
                        <label htmlFor="exampleInputEmail1">
                          Email address
                        </label>
                        <Input placeholder="Enter email" name="email" type="email" value={userProfileInfo.email} onChange={(e) => handleUpdateProfileData(e.target.name, e.target.value)} />
                      </FormGroup>
                    </Col>
                    {(!userSession.is_admin)?
                    <Col className="pl-md-1" md="6">
                      <FormGroup>
                        <label>Phone</label>
                        <Input
                          type="tel"
                          name="contact_no"
                          id="contact_no"
                          placeholder="Enter Contact no. 10 digits long, and start with 7, 8, or 9"
                          pattern="[7/8/9]{1}[0-9]{9}"
                          minLength={10}
                          maxLength={10}
                          value={userProfileInfo.contact_no}
                          onChange={(e) => handleUpdateProfileData(e.target.name, e.target.value)}
                          required
                        />
                      </FormGroup>
                    </Col>
                    :
                    ''
                    }
                  </Row>
                  {(!userSession.is_admin)?
                  <>
                  <Row>
                    <Col className="ml-md-4" md="12">
                      <FormGroup tag="fieldset">
                        <Row>
                          <Col>
                            <Label>
                              Gender
                            </Label>
                          </Col>
                          <Col>
                            <FormGroup check>
                              <Input
                                name="gender"
                                type="radio"
                                id="male"
                                value="Male"
                                checked={(userProfileInfo.gender === 'Male')?true:false}
                                onChange={(e) => handleUpdateProfileData(e.target.name, e.target.value)}
                              />
                              {' '}
                              <Label for="male" className="pl-1" check>
                                Male
                              </Label>
                            </FormGroup>
                          </Col>
                          <Col>
                            <FormGroup check>
                              <Input
                                name="gender"
                                type="radio"
                                id="female"
                                value="Female"
                                checked={(userProfileInfo.gender === 'Female')?true:false}
                                onChange={(e) => handleUpdateProfileData(e.target.name, e.target.value)}
                              />
                              {' '}
                              <Label for="female" className="pl-1" check>
                                Female
                              </Label>
                            </FormGroup>
                          </Col>
                          <Col>
                            <FormGroup check>
                              <Input
                                name="gender"
                                type="radio"
                                id="other"
                                value="Other"
                                checked={(userProfileInfo.gender === 'Other')?true:false}
                                onChange={(e) => handleUpdateProfileData(e.target.name, e.target.value)}
                              />
                              {' '}
                              <Label for="other" className="pl-1" check>
                                Other
                              </Label>
                            </FormGroup>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col md="12">
                      <FormGroup>
                        <label>Address</label>
                        <Input
                          placeholder="Home Address"
                          type="text"
                          name="address"
                          value={userProfileInfo.address}
                          onChange={(e) => handleUpdateProfileData(e.target.name, e.target.value)}
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col className="pr-md-1" md="6">
                      <FormGroup>
                        <label>Landmark</label>
                        <Input
                          placeholder="Landmark"
                          type="text"
                          name="landmark"
                          value={userProfileInfo.landmark}
                          onChange={(e) => handleUpdateProfileData(e.target.name, e.target.value)}
                        />
                      </FormGroup>
                    </Col>
                    <Col className="pl-md-1" md="6">
                      <FormGroup>
                        <label>City</label>
                        <Input
                          placeholder="City"
                          type="text"
                          name="city"
                          value={userProfileInfo.city}
                          onChange={(e) => handleUpdateProfileData(e.target.name, e.target.value)}
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col className="pr-md-1" md="6">
                      <FormGroup>
                        <label>State</label>
                        <Input
                          placeholder="State"
                          type="text"
                          name="state"
                          value={userProfileInfo.state}
                          onChange={(e) => handleUpdateProfileData(e.target.name, e.target.value)}
                        />
                      </FormGroup>
                    </Col>
                    <Col className="pl-md-1" md="6">
                      <FormGroup>
                        <label>Pin Code</label>
                        <Input placeholder="ZIP Code" name="pincode" value={userProfileInfo.pincode} onChange={(e) => handleUpdateProfileData(e.target.name, e.target.value)} />
                      </FormGroup>
                    </Col>
                  </Row>
                  </>
                  :
                  ''
                  }
                </Form>
              </CardBody>
              <CardFooter>
                <Button className="btn-fill" color="primary" type="submit" onClick={() => submitProfileUpdateForm()}>
                  {(isLoading)?
                    <>
                    <Spinner color="dark">
                      Loading...
                    </Spinner>
                    <span>
                      {' '} Saving...
                    </span>
                    </>
                  : "Save"} 
                </Button>
              </CardFooter>
            </Card>
          </Col>
          {/* <Col md="4">
            <Card className="card-user">
              <CardBody>
                <CardText />
                <div className="author">
                  <div className="block block-one" />
                  <div className="block block-two" />
                  <div className="block block-three" />
                  <div className="block block-four" />
                  <a href="#pablo" onClick={(e) => e.preventDefault()}>
                    <img
                      alt="..."
                      className="avatar"
                      src={require("assets/img/emilyz.jpg")}
                    />
                    <h5 className="title">Mike Andrew</h5>
                  </a>
                  <p className="description">Ceo/Co-Founder</p>
                </div>
                <div className="card-description">
                  Do not be scared of the truth because we need to restart the
                  human foundation in truth And I love you like Kanye loves
                  Kanye I love Rick Owens’ bed design but the back is...
                </div>
              </CardBody>
              <CardFooter>
                <div className="button-container">
                  <Button className="btn-icon btn-round" color="facebook">
                    <i className="fab fa-facebook" />
                  </Button>
                  <Button className="btn-icon btn-round" color="twitter">
                    <i className="fab fa-twitter" />
                  </Button>
                  <Button className="btn-icon btn-round" color="google">
                    <i className="fab fa-google-plus" />
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </Col> */}
        </Row>
      </div>
    </>
  );
}

export default UserProfile;
