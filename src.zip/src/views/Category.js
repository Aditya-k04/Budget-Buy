import React, { useState, useEffect, useRef } from "react";

import NotificationAlert from "react-notification-alert";
// reactstrap components
import { Container, Card, CardHeader, CardBody, Row, Col, Input, ButtonGroup, Button, Table, Alert, UncontrolledAlert, Spinner } from "reactstrap";

const Category = () => {
  const [isActive, setIsActive] = useState(false);
  const [isMounted, setIsMounted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [editCategoryEnabled, setEditCategoryEnabled] = useState({
    'active_id': ''
  });
  const [updateCategory, setUpdateCategory] = useState({
    'category': ''
  });
  const [newCategory, setNewCategory] = useState('');
  const [allCategories, setAllCategories] = useState([]);

  useEffect(() => {
    fetch('/api/get-all-categories')
    .then(resp => resp.json())
    .then(result => {
      if(result.length > 0){
        setAllCategories(result)
        setIsMounted(true);
      }
    });
  },[isActive]);

  const handleEditBox = (id, category) => {
    setEditCategoryEnabled({...editCategoryEnabled,['active_id']:id});
    setUpdateCategory({...updateCategory, ["category"]:category});
  }

  const handleCategoryUpdate = (category) => {
    setUpdateCategory({...updateCategory, ["category"]:category});
  }

  console.log(editCategoryEnabled," ::: ",updateCategory);

  const notificationAlertRef = useRef(null);
  
  const notify = (type, place="tr", message) => {
    var options = {};
    options = {
      place: place,
      message: (
        <div>
          <div>
            <b>{message}</b>
          </div>
        </div>
      ),
      type: type,
      icon: "tim-icons icon-bell-55",
      autoDismiss: 3
    };
    notificationAlertRef.current.notificationAlert(options);
  };

  const addCategory = () => {
    setIsLoading(true);
    fetch(`/api/add_category`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({'new_catg': newCategory}),
    })
    .then(resp => resp.json())
    .then(result => {
      if(result?.isSaved) {
        setNewCategory('');
        setIsLoading(false);
        notify("success","tr",'Category Saved!');
        setIsActive(true);
        setIsMounted(false);
        setTimeout(() => {
          setIsActive(false);
        },1000);
      }
    });
  }

  const handleUpdate = (id) => {
    fetch(`/api/update_category`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({'catg_id': id, 'updated_catg': updateCategory.category}),
    })
    .then(resp => resp.json())
    .then(result => {
      if(result?.isUpdated) {
        notify("warning","tr",'Category Updated!');
        setIsActive(true);
        setIsMounted(false);
        setTimeout(() => {
          setIsActive(false);
        },1000);
        handleEditBox('', '');
      }
    });
  }

  const handleDeleteCategory = (id) => {
    fetch(`/api/delete_category`, {
      method: "POST",
      headers: {
          "Content-Type": "application/json",
      },
      body: JSON.stringify({'catg_id': id}),
    })
    .then(resp => resp.json())
    .then(result => {
      if(result?.isDeleted) {
        notify("danger","tr",'Category Deleted!');
        setIsActive(true);
        setTimeout(() => {
          setIsActive(false);
        },1000);
      }
    });
  }

  const addCategoryForm = (
      <Container className="border">
          <h5 className="title text-center">Add New Category</h5>
          <form onSubmit={(e) => e.preventDefault()}>
              <Row className="row-cols-lg-auto g-3 align-items-center justify-content-center">
                  <Col sm={6} md={3} lg={3}>
                      <Input placeholder="Enter Category" bsSize="md" value={newCategory} onChange={(e) => setNewCategory(e.target.value)} />
                  </Col>
                  <Col sm={6} md={2} lg={2}>
                      <Button
                          color="dark"
                          size="md"
                          onClick={() => addCategory()}
                      >
                        {(isLoading)?
                        <Spinner size="md"></Spinner>
                        :
                        ''
                        }
                        <span>
                          {' '}Add
                        </span>
                      </Button>
                  </Col>
              </Row>
          </form>
      </Container>
  );

  const tableHeadings = (
    <thead>
      <tr>
        <th>
            #
        </th>
        <th>
            Category
        </th>
        <th>
            Action
        </th>
      </tr>
    </thead>
  );

  const tableData = isMounted && (
    <tbody>
      {(allCategories.length > 0 )? allCategories.map(({id,category},index) => {
          return(
            <tr key={id}>
              <th scope="row">{index+1}</th>
              <td width="50%">
                {(editCategoryEnabled.active_id === id)?
                <Input value={updateCategory.category} onChange={(e) => handleCategoryUpdate(e.target.value)} />
                :category
                }
              </td>
              <td width="40%">
                <ButtonGroup>
                  {(editCategoryEnabled.active_id === id)?
                    <Button color="info" onClick={() => handleUpdate(id)}><i className="tim-icons icon-single-copy-04" /> Update</Button>
                    :
                    <Button color="secondary" onClick={() => handleEditBox(id, category)}><i className="tim-icons icon-pencil" /> Edit</Button>                    
                  }
                  <Button className="align-items-center" color="danger" onClick={() => handleDeleteCategory(id)}><i className="tim-icons icon-trash-simple" /> Delete</Button>
                </ButtonGroup>
              </td>
            </tr>
          );
        })
        :
        <tr>
          <th scope="row">
            {(!isMounted) ?
              <Spinner>
                Loading...
              </Spinner>
              :
              'No Records Found!'
            }
          </th>
        </tr>
      }
  </tbody>
  );

  const categoriesList = (
      <Table responsive size="sm">
          {tableHeadings}
          {tableData}
      </Table>
  );

  return (
      <>
          <div className="content">
            <div className="react-notification-alert-container">
              <NotificationAlert ref={notificationAlertRef} />
            </div>
              <Row>
                  <Col md="12">
                      <Card>
                          <CardHeader>
                            {addCategoryForm}
                          </CardHeader>
                          <CardBody className="categoryFormWrapper">
                            <Container className="border">
                              {categoriesList}
                            </Container>  
                          </CardBody>
                      </Card>
                  </Col>
              </Row>
          </div>
      </>
  );
}

export default Category;