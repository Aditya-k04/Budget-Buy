import React, { useState, useEffect, useRef } from "react";
import { useHistory, useLocation } from "react-router-dom";
// react plugin for creating notifications over the dashboard
import NotificationAlert from "react-notification-alert";

// reactstrap components
import {
  Button,
  FormGroup,
  Card,
  CardHeader,
  CardImg,
  CardText,
  CardBody,
  CardTitle,
  Row,
  Col,
  Container,
  Form,
  UncontrolledCollapse,
  Label,
  Input
} from "reactstrap";

import MainCarousel from "components/Section/MainCarousel.js";

function StudentDashboard(props) {
    const userSession = JSON.parse(sessionStorage.getItem('user_session'));
    const history = useHistory();
    const location = useLocation();
    const notificationAlertRef = useRef();
    const [allProducts, setAllProducts] = useState([]);
    const [productCategories, setProductCategories] = useState([]);
    const [categories, setCategories] = useState([]);
    const [filterTags, setFilterTags] = useState([]);
    const [productTags, setProductTags] = useState([]);
    const [allProductsLoaded, setAllProductsLoaded] = useState(false);
    const [allCategoriesLoaded, setAllCategoriesLoaded] = useState(false);
    
    const notify = (type,message) => {
        var options = {};
        options = {
            place: "tr",
            message: (
                <div>
                    <div>
                        <b>{message}</b>
                    </div>
                </div>
            ),
            type: type,
            icon: "tim-icons icon-bell-55",
            autoDismiss: 3
        };
        notificationAlertRef.current.notificationAlert(options);
    };

    const getPosts = async () => {
        await fetch(`/api/get-all-products`)
        .then(resp => resp.json())
        .then(result => {
            if(categories.length > 0 && filterTags.length > 0) {
                const newFilteredProducts = result.filter((product, index) => {
                    let existIndex = categories.indexOf(product.category_id);
                    let tagsArr = product.tags.split(",").filter(tag=>tag.trim());
                    let existTags = filterTags.filter((tag, index) => tagsArr.indexOf(tag))
                    console.log("existIndex >> ",existIndex, " tags >> ",existTags);
                    if(existIndex != -1 && existTags.length > 0 && product.stud_id != userSession.id) {
                        return product;
                    }
                }); 
                setAllProducts(newFilteredProducts);
            } else if(categories.length > 0) {
                const newFilteredProducts = result.filter((product, index) => {
                    let existIndex = categories.indexOf(product.category_id);
                    console.log("existIndex >> ",existIndex);
                    if(existIndex != -1 && product.stud_id != userSession.id) {
                        return product;
                    }
                }); 
                setAllProducts(newFilteredProducts);
            } else if(filterTags.length > 0) {
                console.log("filter tags length >> ",filterTags.length);
                const newFilteredProducts = result.filter((product, index) => {
                    let tagsArr = product.tags.split(",");
                    console.log(filterTags," product >> ",tagsArr);
                    let existTags = tagsArr.filter((tag, index) => {
                        console.log(index," << tag >> ",tag.trim());
                        if(filterTags.indexOf(tag.trim()) != -1) {
                            return tag;
                        }
                    })
                    console.log(" exist tags >> ",existTags);
                    if(existTags.length > 0 && product.stud_id != userSession.id) {
                        return product;
                    }
                }); 
                console.log("filtered product >> ",newFilteredProducts);
                setAllProducts(newFilteredProducts);

            } else {
                const othersPosts = result.length > 0 && result?.filter((product, index) => (product.stud_id != userSession.id) && product);
                setAllProducts(othersPosts);
            }
            setAllProductsLoaded(true);
        });
    }

    const getCatgories = async () => {
        await fetch('/api/get-all-categories')
        .then(resp => resp.json())
        .then(result => {
            if(result.length > 0) {
                setProductCategories(result);
                setAllCategoriesLoaded(true);
            }
        });
    }

    const handleCheckFilters = (event) => {
        if(event.target.checked) {
            setCategories([...categories, parseInt(event.target.value)]);
            setAllProductsLoaded(false);
        } else {
            let curr_index = categories.indexOf(parseInt(event.target.value));
            if(curr_index != -1) {
                categories.splice(curr_index, 1);
                setCategories(categories);
                setAllProductsLoaded(false);
            }
        }
    };

    const handleFilterTags = (tags) => {
        console.log(" selected tags :: ",tags);
        setProductTags(tags);
        if(tags != '') {
            let tagsArr = tags.split(",");
            console.log("tagsArr >> ",tagsArr);
            setFilterTags(tagsArr);
        } else {
            setFilterTags([]);
        }
        setAllProductsLoaded(false);
    };

    const handleSortBy = (sort) => {
        if(sort === 'latest') {
            const newFilteredProducts = allProducts.sort((a, b) => new Date(...a.created_at.split('/').reverse()) - new Date(...b.created_at.split('/').reverse()));
            history.push(location.pathname, {'searching': true, 'product_results': newFilteredProducts, 'sort_by': sort});
        } else if(sort === 'lowest-price') {
            const newFilteredProducts = allProducts.sort((a, b) => {
                return a.price - b.price;
            });
            history.push(location.pathname, {'searching': true, 'product_results': newFilteredProducts, 'sort_by': sort});
        } else if(sort === 'highest-price') {
            const newFilteredProducts = allProducts.sort((a, b) => {
                return b.price - a.price;
            });
            history.push(location.pathname, {'searching': true, 'product_results': newFilteredProducts, 'sort_by': sort});
        } else {
            history.push(location.pathname, {'searching': false});
        }        
    }

    useEffect(() => {
        getCatgories();
        if(location?.state?.searching) {
            if(categories.length > 0 && filterTags.length > 0) {
                const newFilteredProducts = location?.state?.product_results.filter((product, index) => {
                    let existIndex = categories.indexOf(product.category_id);
                    let tagsArr = product.tags.split(",");
                    let existTags = filterTags.filter((tag, index) => tagsArr.indexOf(tag))
                    if(existIndex != -1 && existTags.length > 0) {
                        return product;
                    }
                }); 
                setAllProducts(newFilteredProducts);
            } else if(categories.length > 0) {
                const newFilteredProducts = location?.state?.product_results.filter((product, index) => {
                    let existIndex = categories.indexOf(product.category_id);
                    if(existIndex != -1) {
                        return product;
                    }
                }); 
                setAllProducts(newFilteredProducts);
            } else if(filterTags.length > 0) {
                const newFilteredProducts = location?.state?.product_results.filter((product, index) => {
                    let tagsArr = product.tags.split(",");
                    let existTags = filterTags.filter((tag, index) => tagsArr.indexOf(tag))
                    if(existTags.length > 0) {
                        return product;
                    }
                }); 
                setAllProducts(newFilteredProducts);
            } else {
                setAllProducts(location.state?.product_results);
            }
            setAllProductsLoaded(true);
        } else {
            getPosts();
        }
    },[!allProductsLoaded, location]);  

    const categoryChecks = allCategoriesLoaded && productCategories?.length > 0 && productCategories?.map(({id, category},index) => {
        return (
            <FormGroup className="mb-4" inline check>
                <Label className="form-check-label">
                    <Input className="form-check-input" type="checkbox" name="categories" value={id} onChange={(e) => handleCheckFilters(e)} />
                    {category}
                    <span className="form-check-sign">
                        <span className="check"></span>
                    </span>
                </Label>
            </FormGroup>
        );
    });

    const ProductsBody =  allProductsLoaded && allProducts?.length > 0 && allProducts?.map((product,index) => {        
        let dateObj = new Date(product?.use_time);
        let dayVar = (dateObj.getDate() <= 9)?`0${dateObj.getDate()}`:dateObj.getDate();
        let monthVar = ((dateObj.getMonth()+1) <= 9)?`0${(dateObj.getMonth()+1)}`:(dateObj.getMonth()+1);
        let lastDate = `${dayVar}-${monthVar}-${dateObj.getFullYear()}`;
        const oneDay = 24 * 60 * 60 * 1000;
        const firstDate = new Date();
        const diffDays = Math.round(Math.abs((firstDate - dateObj) / oneDay));
        let product_images = [];
        let product_tags = [];
        product?.images?.split(",").map((name,index)=> {
            product_images.push({src: `/public/uploads/products/${name}`, altText: name.split(".")[0], key: index});
        });
        product?.tags?.split(",").map((tag, index)=>{
            product_tags = [...product_tags, tag];
        });        
        
        return (
        <>
        {(product.status == 0) &&
            <Col key={index} className="col-lg-3">
                <Card>
                    {(product_images.length > 1)?
                    <MainCarousel slides={product_images} />
                    :
                    <CardImg src={`/public/uploads/products/${product?.images.split(",")[0]}`} alt={product?.images[0]} style={{'minHeight':'320px'}}></CardImg>
                    }         
                    <CardBody onClick={() => history.push("/students/view_product",{'current_product': product})} style={{'cursor':"pointer"}}>
                        <CardTitle tag="span">{product.tag}</CardTitle>
                        <CardTitle tag="h4">{product.title}</CardTitle>
                        <CardText tag="div">
                            {diffDays} days old
                        </CardText>
                        <CardText className="mt-2" tag="div">
                            {product.price + `/-`}
                        </CardText>
                    </CardBody>
                </Card>
            </Col>            
            }
        </>
      )});
    
  
    return (
        <>
            <div className="content">
                <div className="react-notification-alert-container">
                    <NotificationAlert ref={notificationAlertRef} />
                </div>
                <Card>          
                    <Container>
                        <Row>
                            <Col xs="12">    
                                <CardHeader>
                                    <Container>
                                        <Row>
                                            <Col className="col-12 col-md-8 col-lg-8">
                                                <CardTitle className="mt-2" tag="h3">
                                                    Posts
                                                </CardTitle>
                                            </Col>
                                            <Col className="col-12 col-md-4 col-lg-4">
                                                <Container>
                                                    <Row>
                                                        <Col className="col-6">
                                                            <FormGroup>
                                                                <Button
                                                                    color="primary"
                                                                    id="toggler"
                                                                    className="filterBtn d-inline-block w-100"
                                                                >
                                                                    Filters
                                                                </Button>
                                                            </FormGroup>
                                                        </Col>
                                                        <Col className="col-6">
                                                            <FormGroup>
                                                                <Input className="mt-2" type="select" name="select" id="sortBy" onChange={(e) => handleSortBy(e.target.value)} > 
                                                                    <option value="">Sort By</option>
                                                                    <option value="latest" selected={(location?.state?.sort_by === 'latest')?true:false}>Latest</option>
                                                                    <option value="lowest-price" selected={(location?.state?.sort_by === 'lowest-price')?true:false}>Lowest Price</option>
                                                                    <option value="highest-price" selected={(location?.state?.sort_by === 'highest-price')?true:false}>Highest Price</option>
                                                                    {/* <option value="used-by" selected={(location?.state?.sort_by === 'used-by')?true:false}>Minimum Used</option> */}
                                                                </Input>
                                                            </FormGroup>
                                                        </Col>
                                                    </Row>
                                                </Container>
                                            </Col>
                                            <Col className="col-12 col-md-12 col-lg-12">
                                                <UncontrolledCollapse toggler="#toggler">
                                                    <Card>
                                                        <CardBody>
                                                            <Container> 
                                                                <Row>
                                                                    <Col className="col-12">
                                                                        <CardText tag="h6">Categories</CardText>
                                                                        {categoryChecks}
                                                                    </Col>
                                                                    <Col className="col-12">
                                                                        <CardText tag="h6">Tags</CardText>
                                                                        <Input
                                                                            placeholder="Enter Tags by comma separated"
                                                                            bsSize="sm"
                                                                            value={productTags}
                                                                            onChange={(e) => handleFilterTags(e.target.value)}
                                                                        />
                                                                    </Col>
                                                                </Row>
                                                            </Container>
                                                        </CardBody>
                                                    </Card>
                                                </UncontrolledCollapse>
                                            </Col>
                                        </Row>
                                    </Container>
                                </CardHeader>
                                {(allProducts.length > 0) ?
                                <CardBody>
                                    <Container>
                                        <Row>
                                            {ProductsBody}
                                        </Row>
                                    </Container>
                                </CardBody>
                                :
                                <CardBody>
                                    No posts found!
                                </CardBody>
                                }
                            </Col>
                        </Row>
                    </Container>
                </Card>
            </div>
        </>
    );
}

export default StudentDashboard;
