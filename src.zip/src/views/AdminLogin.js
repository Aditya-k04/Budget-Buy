import Admin from "layouts/Admin/Admin";
import React, { useState, useEffect, useRef } from "react";
import { Link, useHistory } from "react-router-dom";

// react plugin for creating notifications over the dashboard
import NotificationAlert from "react-notification-alert";

import {
  FormGroup,
  Label,
  Input,
  Button,
  Card,
  CardBody,
  Col,
  Container,
  Row,
  CardHeader,
  CardTitle
} from "reactstrap";

const AdminLogin = () => {
  const notificationAlertRef = useRef(null);
  const notify = (type,message) => {
    var options = {};
    options = {
      place: "tr",
      message: (
        <div>
          <div>
            <b>{message}</b>
          </div>
        </div>
      ),
      type: type,
      icon: "tim-icons icon-bell-55",
      autoDismiss: 3
    };
    notificationAlertRef?.current?.notificationAlert(options);
  };
  let history = useHistory();
  const [loginData, setLoginData] = useState({
    email: '',
    password: ''
  });

  const handleLoginData = (key, value) => {
    setLoginData({...loginData, [key]: value});
  }

  const handleLogin = () => {
    fetch(`/api/isExistUser`, {
      method: "POST",
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(loginData),
    })
    .then(response => response.json())
    .then(data => {
      if(data?.userSession?.length > 0 && data.userSession[0]?.is_admin) {
        notify("success","Login Success!");
        sessionStorage.setItem("user_session", JSON.stringify({'id': data.userSession[0]?.id, 'email': data.userSession[0]?.email, 'first_name': data.userSession[0]?.first_name, 'last_name': data.userSession[0]?.last_name, 'is_admin': data.userSession[0]?.is_admin}));
        history.push('/admin/dashboard');
      } else {
        notify("warning","Invalid Master User Credentials!");
      }
    });
  }

  return (
    <Container fluid>
        <div className="react-notification-alert-container">
            <NotificationAlert ref={notificationAlertRef} />
        </div>
        <Row className="align-items-center" style={{'minHeight':'98vh'}}>
            <Col lg="12" md="12" xs="12">
                <Card className="col-4 m-auto">
                    <CardHeader>
                        <CardTitle tag="h4"><b>Master User Login</b></CardTitle>
                    </CardHeader>
                    <CardBody>
                        <form onSubmit={e => {e.preventDefault();handleLogin();}}>
                            <FormGroup>
                            <Label for="email">Email address</Label>
                            <Input
                                type="email"
                                name="email"
                                id="email"
                                placeholder="Enter email"
                                value={loginData.email}
                                onChange={(e) => handleLoginData(e.target.name, e.target.value)}
                                required
                            />
                            </FormGroup>
                            <FormGroup>
                            <Label for="password">Password</Label>
                            <Input
                                type="password"
                                name="password"
                                id="password"
                                placeholder="Password"
                                pattern="(?=[A-Za-z0-9@#$%^&+!=]+$)^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&+!=])(?=.{8,}).*$"
                                autoComplete="off"
                                value={loginData.password}
                                onChange={(e) => handleLoginData(e.target.name, e.target.value)}
                                title="At least 8 characters, min 1 Uppercase 1 Lowercase 1 Number 1 special character and only contains symbols from the alphabet, num"
                                required="At least 8 characters, min 1 Uppercase 1 Lowercase 1 Number 1 special character and only contains symbols from the alphabet, num"
                            />
                            </FormGroup>
                            <Button color="warning" type="submit">
                                Submit
                            </Button>
                        </form>
                    </CardBody>
                </Card>
            </Col>
        </Row>
    </Container>
  );
};

export default AdminLogin;
