import React, { useState, useRef, useEffect } from "react";
import { useHistory, useLocation } from "react-router-dom";

// react plugin for creating notifications over the dashboard
import NotificationAlert from "react-notification-alert";

import {
    Breadcrumb, 
    BreadcrumbItem,
    FormGroup,
    Label,
    Input,
    FormText,
    Badge,
    Card,
    CardTitle,
    CardBody,
    CardImg,
    Row,
    Col,
    CardText,
    Container,
    CardFooter
} from "reactstrap";

import MainCarousel from "components/Section/MainCarousel.js";
import WhatsAppPlugin from "components/FixedPlugin/WhatsappPlugin";

const ViewProduct = (props) => {  
    const userSession = JSON.parse(sessionStorage.getItem('user_session'));
    const location = useLocation();
    const history = useHistory();
    const notificationAlertRef = useRef(null);
    const [currentProduct, setCurrentProduct] = useState(props.location.state.current_product);
    const [currentProductLoaded, setCurrProductLoaded] = useState(true);

    const notify = (type,message) => {
        var options = {};
        options = {
            place: "tr",
            message: (
                <div>
                    <div>
                        <b>{message}</b>
                    </div>
                </div>
            ),
            type: type,
            icon: "tim-icons icon-bell-55",
            autoDismiss: 3
        };
        notificationAlertRef.current.notificationAlert(options);
    };

    useEffect(() => {
        setCurrProductLoaded(true);
    }, [!currentProductLoaded]);

    console.log("current product >> ",currentProduct);

    const purchaseProduct = async (product) => {
        await fetch(`/api/purchase-product`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({'product': product, 'user_id': userSession?.id}),
        })
        .then(resp => resp.json())
        .then(result => {
            if(result.affectedRows) {
                notify("success",'Order placed!');
                history.push("/students/checkout");
            }
        });
    }

    const ProductsBody = () => {
        let product_images = [];
        if(currentProduct?.images?.split(",").length > 0) {
            currentProduct?.images?.split(",").map((name,index)=> {
                product_images.push({src: `/public/uploads/products/${name}`, altText: name.split(".")[0], key: index});
            });
        }

        return (
            <>
                <Col key={currentProduct?.id} className="col-12 col-md-6 col-lg-6 pb-4">
                    {(product_images.length > 1)?
                    <MainCarousel slides={product_images} />
                    :
                    <CardImg src={`/public/uploads/products/${currentProduct.images.split(",")[0]}`} alt={product_images[0].altText}></CardImg>
                    }
                </Col>
                <Col key={currentProduct?.id} className="col-12 col-md-6 col-lg-6 p-4">
                    <CardText tag="p">{currentProduct?.category}</CardText>
                    <CardTitle tag="h3">{currentProduct?.title}</CardTitle>
                    <CardText tag="p"><b>Initial Usage date : </b>{new Date(currentProduct?.use_time).getDate()+'-'+(new Date(currentProduct?.use_time).getMonth()+1)+'-'+new Date(currentProduct?.use_time).getFullYear()}</CardText>
                    <CardText tag="span">
                        <b>Price :</b> Rs.{currentProduct?.price} /-
                    </CardText>
                    {(currentProduct?.status === 0)?
                    <>
                        <CardText className="mt-2" tag="h6">
                            <b>Seller : </b> {currentProduct?.first_name+' '+currentProduct?.last_name}
                        </CardText>
                        <CardText className="mt-2" tag="h6">
                            <b>Seller Email : </b> {currentProduct?.email}
                        </CardText>
                        <CardText className="mt-2" tag="h6">
                            <b>Seller Contact No : </b> {currentProduct?.phone}
                        </CardText>
                    </>
                    :
                    <CardText>
                    <Badge color="warning" style={{'fontSize':'16px'}}>Sold Out</Badge>
                    </CardText>
                    }
                    <CardText className="mt-2" tag="p"><b>Description: </b><br />{currentProduct?.description}</CardText>
                </Col>
            </>
        );
    }

    return (
        <div className="content">
            <WhatsAppPlugin sellerPhone={currentProduct?.phone} />
            <div className="react-notification-alert-container">
                <NotificationAlert ref={notificationAlertRef} />
            </div>
            <Row>
                <Col>
                    <Card>
                        <CardBody>
                            <Container>
                                <Row>
                                    <ProductsBody />
                                </Row>
                            </Container>
                        </CardBody>
                    </Card>
                </Col>
            </Row>
        </div>
    );
};

export default ViewProduct;
