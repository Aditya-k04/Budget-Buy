import React, { useEffect, useState, useRef } from "react";

import NotificationAlert from "react-notification-alert";
import { Container, Card, CardHeader, CardBody, Row, Col, Input, ButtonGroup, Button, Table, UncontrolledAlert, Spinner, NavLink, FormGroup } from "reactstrap";

const Students = () => {
    const [isMounted, setIsMounted] = useState(false);
    const [studentsList, setStudentsList] = useState();

    const notificationAlertRef = useRef(null);
  
    const notify = (type, place="tr", message) => {
      var options = {};
      options = {
          place: place,
          message: (
              <div>
              <div>
                  <b>{message}</b>
              </div>
              </div>
          ),
          type: type,
          icon: "tim-icons icon-bell-55",
          autoDismiss: 3
      };
      notificationAlertRef.current.notificationAlert(options);
    };

    useEffect(() => {
      fetch(`/api/admin-students-list`)
      .then(resp => resp.json())
      .then(result => {
        if(result.length > 0) {
          setStudentsList(result);
          setIsMounted(true);
        }
      });
    },[!isMounted]);

    const handleVerifyStudent = (studentId, user) => {
      fetch(`/api/verify-student`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({'student_id': studentId}),
      })
      .then(resp => resp.json())
      .then(result => {
        if(result?.affectedRows) {
          setIsMounted(false);
          notify("info","tr",`${user} verified successfully!`);
        }
      });
    }

    const handleDeleteStudent = (studId, user) => {      
      fetch(`/api/delete-student`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({'student_id': studId}),
      })
      .then(resp => resp.json())
      .then(result => {
        if(result?.affectedRows) {
          notify("success","tr",`${user} Deleted!`);
          setTimeout(() => setIsMounted(false), 1500);
        }
      });
    };

    const tableHeadings = (
      <thead>
        <tr>
          <th>
              #
          </th>
          <th>
              Name
          </th>
          <th>
              Email
          </th>
          <th>
              Gender
          </th>
          <th>
              Document
          </th>
          <th>
              Action
          </th>
        </tr>
      </thead>
    );
  
    const tableData = isMounted && (
      <tbody>
        {(studentsList.length > 0 )? studentsList.map(({id,first_name, last_name, email, gender, document, is_verified},index) => {
            return(
              <tr key={id}>
                <th scope="row">{index+1}</th>
                <td>
                  {first_name} {last_name}
                </td>
                <td>
                  {email}
                </td>
                <td>
                  {gender}
                </td>
                <td>                  
                  {(document)?<NavLink href={`http://localhost:3001/public/uploads/student_docs/${document}`} target="_blank" rel='noopener noreferrer'>View Document</NavLink>:'No File'}
                </td>
                <td>
                  <FormGroup inline>
                    <Button color={(is_verified)?'success':'danger'} onClick={() => handleVerifyStudent(id, email)} disabled={(is_verified)?true:false}>{(is_verified)?'Verified':'Verify'}</Button>
                    <Button className="ml-2" title="Delete Student" onClick={() => handleDeleteStudent(id, email)}><i className="tim-icons icon-trash-simple"/></Button>
                  </FormGroup>
                </td>
              </tr>
            );
          })
          :
          <tr>
            <th scope="row">
              {(!isMounted) ?
                <Spinner>
                  Loading...
                </Spinner>
                :
                'No Records Found!'
              }
            </th>
          </tr>
        }
      </tbody>
    );
  
    const verifiedStudentsList = (
      <Table responsive>
          {tableHeadings}
          {tableData}
      </Table>
    );

    return (
        <>
          <div className="content">
            <div className="react-notification-alert-container">
              <NotificationAlert ref={notificationAlertRef} />
            </div>
              <Row>
                <Col md="12">
                  <Card>
                    <CardHeader>
                      <h5>Students Verified List</h5>
                    </CardHeader>
                    <CardBody className="categoryFormWrapper">
                      <Container className="border">
                        {verifiedStudentsList}
                      </Container>  
                    </CardBody>
                  </Card>
                </Col>
              </Row>
          </div>
        </>
    );
}

export default Students;