import React, { useRef } from "react";

const Toast = (alertRef,toastType,toastMsg) => {
    var options = {};
    options = {
        place: "tr",
        message: (
            <div>
            <div>
                <b>{toastMsg}</b>
            </div>
            </div>
        ),
        type: toastType,
        icon: "tim-icons icon-bell-55",
        autoDismiss: 3
    };
    alertRef.current.notificationAlert(options);

    return alertRef;
}

export default Toast;