import react from "react";
import { NavLink } from "reactstrap";

const WhatsAppPlugin = (props) => {
    return <NavLink className="wpChatPlugin" href={`https://wa.me/${props?.sellerPhone}`}><img src="/public/uploads/WhatsAppButtonGreenSmall.png" /></NavLink>
}

export default WhatsAppPlugin;