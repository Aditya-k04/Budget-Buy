import React, { useState, useRef, useEffect } from "react";
import { Link, useHistory } from "react-router-dom";

// react plugin for creating notifications over the dashboard
import NotificationAlert from "react-notification-alert";
import Toast from "components/FixedPlugin/Toast.js";

import {
  FormGroup,
  Label,
  Input,
  FormText,
  Button,
  Card,
  CardHeader, 
  CardImg, 
  CardBody, 
  CardText,
  Row,
  Col,
  CardTitle,
  Container,
  Form
} from "reactstrap";

const AddProducts = (props) => {      
    const userSession = JSON.parse(sessionStorage.getItem("user_session"));
    // console.log("userSession >>> ",userSession);
    const notificationAlertRef = useRef(null);
    let history = useHistory();
    const [productCategories, setProductCategories] = useState([]);
    const [isLoadedData, setIsLoadedData] = useState(false);
    const [isLoadingImgs, setIsLoadingImgs] = useState(true);
    const [productImageUrl, setProductImageUrl] = useState([]);
    const [productForm, setProductForm] = useState({
        stud_id: userSession.id,
        category_id: '',
        product_title: '',
        product_images: [],
        product_description: '',
        product_price: '',
        product_tags: '',
        used_time: '',
        status: ''
    });

    const getCatgories = async () => {
        await fetch('/api/get-all-categories')
        .then(resp => resp.json())
        .then(result => {
            if(result.length > 0) {
                setProductCategories(result);
                setIsLoadedData(true);
            }
        });
    }

    useEffect(() => {
        getCatgories();
        setIsLoadingImgs(true)
    },[!isLoadingImgs, !isLoadedData]);

    const handleProductForm = (key,value,index = 0) => {
        if(key === `product_img_${index}` && value) {
            const render = new FileReader();
            render.addEventListener("load", () => {
                if(productImageUrl[index]) {
                    productImageUrl[index] = render.result;
                    setProductImageUrl(productImageUrl);
                    setIsLoadingImgs(false);
                } else {
                    setProductImageUrl([...productImageUrl, [index]=render.result]);
                }
            });
            render.readAsDataURL(value);
        } else if(key === `upload_img_${index}`) {
            const render = new FileReader();
            render.addEventListener("load", () => {
                if(productImageUrl[index]) {
                    productImageUrl[index] = render.result;
                    setProductImageUrl(productImageUrl);
                    setIsLoadingImgs(false);
                } else {
                    setProductImageUrl([...productImageUrl, [index]=render.result]);
                }
            });
            render.readAsDataURL(value);
            productForm.product_images[index] = value
            setProductForm(productForm);
        } else {
            setProductForm({...productForm, [key]:value});
        }        
    }

    const submitStudentForm = async() => {
        let formData = new FormData();
        for (const file of productForm.product_images) {
            formData.append('product_images', file) ;
        }
        formData.append("product",JSON.stringify(productForm));
        try {
            await fetch(`/api/add-product`, {
                method: 'POST',
                body: formData,
            })
            .then(resp => resp.json())
            .then(result => {
                if(result?.affectedRows) {
                    props.handlerAllProductsLoaded(false);
                    props.handlerProductAction('');
                }
            });    
        } catch (error) {
            console.log("error >> ",error);
        }
    }

    return (
        <>
        <div className="content">
            <div className="react-notification-alert-container">
                <NotificationAlert ref={notificationAlertRef} />
            </div>
            <div className="addStudentWrapper">
                <Row>
                    <Card>
                        <CardHeader>
                            <CardTitle className="pl-3 pr-3 mt-2 d-flex align-items-center justify-content-between" tag="h3">
                                Add New Product
                                <Button color="danger" onClick={() => props.handlerProductAction('')}>Cancel</Button>
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <form encType="multipart/form-data" onSubmit={e => {e.preventDefault(); submitStudentForm();}}>
                                <Container>
                                    <Row>
                                        <Col>
                                            <FormGroup>
                                                <Label for="product_name">Product Title</Label>
                                                <Input
                                                    type="text"
                                                    name="product_title"
                                                    id="product_name"
                                                    placeholder="Enter Product Title"
                                                    value={productForm?.product_title}
                                                    onChange={(e) => handleProductForm(e.target.name, e.target.value)}
                                                />
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </Container>
                                <Container>
                                    <Row>
                                        <Col>
                                            <Container className="border">
                                                <Row className="justify-content-center">
                                                    {
                                                        (isLoadingImgs && productImageUrl?.length > 0) ? productImageUrl?.map((img,index) => 
                                                            (
                                                                <Col key={index} className="col-lg-3">
                                                                    <FormGroup>
                                                                        <Label for={`product_img_${index}`} style={{"cursor":"pointer"}}>
                                                                            <Card className="productImageWrapper mb-0">
                                                                                <CardImg  src={(img !== undefined)?img:require('assets/img/image_placeholder.jpg')} alt="Image Preview" />
                                                                            </Card>       
                                                                        </Label>
                                                                        <Input
                                                                            key={index}
                                                                            type="file"
                                                                            name={`product_img_${index}`}
                                                                            onChange={(e) => handleProductForm(e.target.name, e.target.files[0], index)}
                                                                            style={{"cursor":"pointer"}}
                                                                            title={(productForm?.product_images[index] !== undefined)?productForm?.product_images[index].name:'Please choose file!'}
                                                                        />
                                                                    </FormGroup>
                                                                </Col>
                                                            )
                                                        ):
                                                        (
                                                            <Col className="col-lg-4 mt-2">
                                                                <p className="text-primary">Upload upto 8 images,<br /> Uploaded Images will be shown here.</p>
                                                            </Col>
                                                        )
                                                    }
                                                </Row>
                                                <Row className="justify-content-center">
                                                    { productImageUrl?.length < 8 && ( 
                                                    <Col className="col-lg-3">
                                                        <FormGroup className="mt-2">
                                                            <Label className="uploadBtn" for={`upload_image_${productImageUrl?.length}`} style={{"cursor":"pointer"}}>
                                                                <Card className="productImageWrapper mb-0">
                                                                    <CardText color="bg-primary" tag="span">Upload Image ({productImageUrl?.length} / 8)</CardText>
                                                                </Card>       
                                                            </Label>
                                                            <Input
                                                                key={productImageUrl.length}
                                                                type="file"
                                                                id={`upload_image_${productImageUrl.length}`} 
                                                                name={`upload_img_${productImageUrl.length}`}
                                                                onChange={(e) => handleProductForm(e.target.name,e.target.files[0], productImageUrl.length)}
                                                                style={{"cursor":"pointer"}}
                                                                title="Please choose file!"
                                                            />
                                                        </FormGroup>    
                                                    </Col>
                                                    )}
                                                </Row>
                                            </Container>
                                        </Col>
                                    </Row>
                                </Container>
                                <Container>
                                    <Row>
                                        <Col>
                                            <FormGroup>
                                                <Label for="product_desc">Product Description</Label>
                                                <Input placeholder="Enter product description" type="textarea" name="product_description" id="product_desc" value={productForm?.product_description} onChange={(e) => handleProductForm(e.target.name, e.target.value)} />
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <FormGroup>
                                                <Label for="product_tags">Product Tags</Label>
                                                <Input placeholder="Enter product tags" name="product_tags" id="product_tags" value={productForm?.product_tags} onChange={(e) => handleProductForm(e.target.name, e.target.value)} />
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <FormGroup>
                                                <Label for="product_category">Category</Label>
                                                <Input type="select" name="category_id" id="product_category" onChange={(e) => handleProductForm(e.target.name, e.target.value)} required>
                                                    <option key="-1">Choose Category</option>
                                                    { (isLoadedData) && productCategories?.map(({id,category},index) => (
                                                        <option key={index} value={id}>{category}</option>
                                                    ))
                                                    }
                                                </Input>
                                            </FormGroup>
                                        </Col>
                                        <Col>
                                            <FormGroup>
                                                <Label for="product_time">Using From</Label>
                                                <Input name="used_time" id="product_time" placeholder="dd-mm-yyyy" bsSize="" type="date" onChange={(e) => handleProductForm(e.target.name, e.target.value)} />
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col>
                                            <FormGroup>
                                                <Label for="product_price">Price</Label>
                                                <Input placeholder="Enter product price" type="number" name="product_price" id="product_price" onChange={(e) => handleProductForm(e.target.name, e.target.value)} />
                                            </FormGroup>
                                        </Col>
                                        <Col>
                                            <FormGroup>
                                                <Label for="product_status">Status</Label>
                                                <Input placeholder="Enter product status" name="status" id="product_status" type="select" onChange={(e) => handleProductForm(e.target.name, e.target.value)}>
                                                    <option value="0">Active</option>
                                                    <option value="1">Sold</option>
                                                </Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col className="col-lg-12">
                                            <FormGroup>
                                                <Button color="primary" type="submit">Save</Button>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </Container>
                            </form>
                        </CardBody>
                    </Card>
                </Row>
            </div>        
        </div>
        </>
    );
};

export default AddProducts;
