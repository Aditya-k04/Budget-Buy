import React, { useState, useRef, useEffect } from "react";
import { Link, useHistory } from "react-router-dom";

// react plugin for creating notifications over the dashboard
import NotificationAlert from "react-notification-alert";
import Toast from "components/FixedPlugin/Toast.js";

import {
    FormGroup,
    Label,
    Input,
    Button,
    Card,
    CardHeader,
    CardImg,
    CardBody,
    CardText,
    Row,
    Col,
    CardTitle,
    Container,
    Form
} from "reactstrap";

const EditProducts = (props) => {
    console.log("props >> ",props);
    const notificationAlertRef = useRef(null);
    let history = useHistory();
    const [productCategories, setProductCategories] = useState([]);
    const [isLoadedData, setIsLoadedData] = useState(false);
    const [isLoadingImgs, setIsLoadingImgs] = useState(false);
    const [productImageUrl, setProductImageUrl] = useState([]);
    const [productForm, setProductForm] = useState({
        id: props.productData.id,
        stud_id: '',
        category_id: '',
        product_title: '',
        product_images: [],
        product_description: '',
        product_price: '',
        product_tags: '',
        used_time: '',
        status: ''
    });

    const getCatgories = async () => {
        await fetch('/api/get-all-categories')
        .then(resp => resp.json())
        .then(result => {
            if (result.length > 0) {
                setProductCategories(result);
                setIsLoadedData(true);
            }
        });
    }

    useEffect(() => {
        if(productImageUrl?.length == 0) {
            console.log("updating product >> ", props.productData);
            let dateObj = new Date(props.productData.use_time);
            let dayVar = (dateObj.getDate() <= 9)?`0${dateObj.getDate()}`:dateObj.getDate();
            let monthVar = ((dateObj.getMonth()+1) <= 9)?`0${(dateObj.getMonth()+1)}`:(dateObj.getMonth()+1);
            let lastDate = `${dateObj.getFullYear()}-${monthVar}-${dayVar}`;
            setProductForm({ ...productForm, ['stud_id']: props.productData.stud_id, ['category_id']: props.productData.category_id, ['product_title']: props.productData.title, ['product_images']: props.productData.images.split(","), ['product_description']: props.productData.description, ['product_tags']: props.productData.tags, ['used_time']: lastDate, ['product_price']: props.productData.price, ['status']: props.productData.status });
            props.productData.images.split(",").map((image, index) => {
                productImageUrl[index] = `/public/uploads/products/${image}`;
                setProductImageUrl(productImageUrl);
            });            
        }
        getCatgories();
        setIsLoadingImgs(true);
    }, [!isLoadingImgs, !isLoadedData]);

    const notify = (type,message) => {
        var options = {};
        options = {
        place: "tr",
        message: (
            <div>
                <div>
                    <b>{message}</b>
                </div>
            </div>
        ),
        type: type,
        icon: "tim-icons icon-bell-55",
        autoDismiss: 3
        };
        notificationAlertRef.current.notificationAlert(options);
    };

    console.log("loaded images >> ", productImageUrl);

    const handleProductForm = (key, value, index = 0) => {
        console.log(key, " >>> ", value, " >>> ", index);
        if (key === `product_img_${index}` && value) {
            const render = new FileReader();
            render.addEventListener("load", () => {
                if (productImageUrl[index]) {
                    console.log(productImageUrl[index], " >>>>>  ", render.result);
                    productImageUrl[index] = render.result;
                    console.log(productImageUrl[index], " >>>>>  ", render.result);
                    setProductImageUrl(productImageUrl);
                    setIsLoadingImgs(false);
                } else {
                    setProductImageUrl([...productImageUrl, [index] = render.result]);
                }
            });
            render.readAsDataURL(value);
            productForm.product_images[index] = value;
            setProductForm(productForm);
        } else if (key === `upload_img_${index}`) {
            const render = new FileReader();
            render.addEventListener("load", () => {
                if (productImageUrl[index]) {
                    console.log(productImageUrl[index], " >>>>>  ", render.result);
                    productImageUrl[index] = render.result;
                    setProductImageUrl(productImageUrl);
                    setIsLoadingImgs(false);
                } else {
                    setProductImageUrl([...productImageUrl, [index] = render.result]);
                }
            });
            render.readAsDataURL(value);
            productForm.product_images[index] = value;
            setProductForm(productForm);
        } else {
            setProductForm({ ...productForm, [key]: value });
        }
    }

    const submitStudentForm = () => {
        console.log("product form >>> ",productForm);
        let formData = new FormData();
        for (const file of productForm.product_images) {
            console.log("type of file >>> ",typeof file);
            if(typeof file === 'object') {
                formData.append('product_images', file);
            }
        }
        formData.append("product",JSON.stringify(productForm));
        console.log("product_images >> ",formData.get('product_images'));
        try {
            fetch(`/api/update-product`, {
                method: 'POST',
                body: formData,
            })
            .then(resp => resp.json())
            .then(result => {
                console.log("result >>> ",result);
                if (result?.affectedRows) {
                    setIsLoadingImgs(false);
                    notify('success', 'Product Updated!');
                    props.handlerAllProductsLoaded(false);
                    props.handlerProductAction('');
                }
            });
        } catch (error) {
            console.log("error >> ", error);
        }
    }

    console.log("date > ",productForm.used_time);

    return (
        <>
            <div className="content">
                <div className="react-notification-alert-container">
                    <NotificationAlert ref={notificationAlertRef} />
                </div>
                <div className="addStudentWrapper">
                    <Row>
                        <Card>
                            <CardHeader>
                                <CardTitle className="pl-3 pr-3 mt-2 d-flex align-items-center justify-content-between" tag="h3">
                                    Edit Product
                                    <Button color="danger" onClick={() => props.handlerProductAction('')}>Cancel</Button>
                                </CardTitle>
                            </CardHeader>
                            <CardBody>
                                <form encType="multipart/form-data" onSubmit={e => { e.preventDefault(); submitStudentForm(); }}>
                                    <Container>
                                        <Row>
                                            <Col>
                                                <FormGroup>
                                                    <Label for="product_name">Product Title</Label>
                                                    <Input
                                                        type="text"
                                                        name="product_title"
                                                        id="product_name"
                                                        placeholder="Enter Product Title"
                                                        value={productForm.product_title}
                                                        onChange={(e) => handleProductForm(e.target.name, e.target.value)}
                                                    />
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </Container>
                                    <Container>
                                        <Row>
                                            <Col>
                                                <Container className="border">
                                                    <Row className="justify-content-center">
                                                        {
                                                            (isLoadingImgs && productImageUrl.length > 0) ? productImageUrl.map((img, index) => {
                                                                console.log("image  >> ",img);
                                                                return (
                                                                    <Col key={index} className="col-lg-3">
                                                                        <FormGroup>
                                                                            <Label for={`product_img_${index}`} style={{ "cursor": "pointer" }}>
                                                                                <Card className="productImageWrapper mb-0">
                                                                                    <CardImg src={(img !== undefined) ? img : 'uploads/image_placeholder.jpg'} alt="Image Preview" />
                                                                                </Card>
                                                                            </Label>
                                                                            <Input
                                                                                key={index}
                                                                                type="file"
                                                                                name={`product_img_${index}`}
                                                                                onChange={(e) => handleProductForm(e.target.name, e.target.files[0], index)}
                                                                                style={{ "cursor": "pointer" }}
                                                                                title={(productForm.product_images[index].name !== undefined) ? productForm.product_images[index].name : 'Please choose file!'}
                                                                            />
                                                                        </FormGroup>
                                                                    </Col>
                                                                )
                                                            }
                                                            ) :
                                                                (
                                                                    <Col className="col-lg-4 mt-2">
                                                                        <p className="text-primary">Upload upto 8 images,<br /> Uploaded Images will be shown here.</p>
                                                                    </Col>
                                                                )
                                                        }
                                                    </Row>
                                                    <Row className="justify-content-center">
                                                        {productImageUrl.length < 8 && (
                                                            <Col className="col-lg-3">
                                                                <FormGroup className="mt-2">
                                                                    <Label className="uploadBtn" for={`upload_image_${productImageUrl.length}`} style={{ "cursor": "pointer" }}>
                                                                        <Card className="productImageWrapper mb-0">
                                                                            <CardText color="bg-primary" tag="span">Upload Image ({productImageUrl.length} / 8)</CardText>
                                                                        </Card>
                                                                    </Label>
                                                                    <Input
                                                                        key={productImageUrl.length}
                                                                        type="file"
                                                                        id={`upload_image_${productImageUrl.length}`}
                                                                        name={`upload_img_${productImageUrl.length}`}
                                                                        onChange={(e) => handleProductForm(e.target.name, e.target.files[0], productImageUrl.length)}
                                                                        style={{ "cursor": "pointer" }}
                                                                        title="Please choose file!"
                                                                    />
                                                                </FormGroup>
                                                            </Col>
                                                        )}
                                                    </Row>
                                                </Container>
                                            </Col>
                                        </Row>
                                    </Container>
                                    <Container>
                                        <Row>
                                            <Col>
                                                <FormGroup>
                                                    <Label for="product_desc">Product Description</Label>
                                                    <Input placeholder="Enter product description" type="textarea" name="product_description" id="product_desc" value={productForm.product_description} onChange={(e) => handleProductForm(e.target.name, e.target.value)} />
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col>
                                                <FormGroup>
                                                    <Label for="product_tags">Product Tags</Label>
                                                    <Input placeholder="Enter product tags" name="product_tags" id="product_tags" value={productForm.product_tags} onChange={(e) => handleProductForm(e.target.name, e.target.value)} />
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col>
                                                <FormGroup>
                                                    <Label for="product_category">Category</Label>
                                                    <Input type="select" name="category_id" id="product_category" onChange={(e) => handleProductForm(e.target.name, e.target.value)} required>
                                                        <option key="-1">Choose Category</option>
                                                        {(isLoadedData) && productCategories.map(({ id, category }, index) => (
                                                            <option key={index} value={id} selected={(props.productData.category_id == id) ? true : false}>{category}</option>
                                                        ))
                                                        }
                                                    </Input>
                                                </FormGroup>
                                            </Col>
                                            <Col>
                                                <FormGroup>
                                                    <Label for="product_time">Using From</Label>
                                                    <Input placeholder="dd-mm-yyyy" bsSize="" type="date" name="used_time" id="product_time" defaultValue={productForm.used_time} onChange={(e) => handleProductForm(e.target.name, e.target.value)} />
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col>
                                                <FormGroup>
                                                    <Label for="product_price">Price</Label>
                                                    <Input placeholder="Enter product price" type="number" name="product_price" id="product_price" value={productForm.product_price} onChange={(e) => handleProductForm(e.target.name, e.target.value)} />
                                                </FormGroup>
                                            </Col>
                                            <Col>
                                                <FormGroup>
                                                    <Label for="product_status">Status</Label>
                                                    <Input placeholder="Enter product status" name="status" id="product_status" type="select" onChange={(e) => handleProductForm(e.target.name, e.target.value)} defaultValue={productForm.status} >
                                                        <option value="0" selected={(productForm.status == 0)?true:false}>Active</option>
                                                        <option value="1" selected={(productForm.status == 1)?true:false}>Sold</option>
                                                    </Input>
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col className="col-lg-12">
                                                <FormGroup>
                                                    <Button color="primary" type="submit">Update</Button>
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </Container>
                                </form>
                            </CardBody>
                        </Card>
                    </Row>
                </div>
            </div>
        </>
    );
};

export default EditProducts;
