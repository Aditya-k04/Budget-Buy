import Dashboard from "views/Dashboard.js";
import Category from "views/Category.js";
import Icons from "views/Icons.js";
import Notifications from "views/Notifications.js";
import UserProfile from "views/UserProfile.js";
import Students from "views/Students.js";
import StudentDashboard from "views/StudentDashboard.js";
import StudentProducts from "views/StudentProducts.js";
import ViewProduct from "views/ViewProduct.js";
import Orders from "views/Orders.js";
import MyOrders from "views/MyOrders";

var routes = [  
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: "tim-icons icon-chart-pie-36",
    component: Dashboard,
    layout: "/admin",
    inSidebar: true,
  },
  {
    path: "/category",
    name: "Categories",
    icon: "tim-icons icon-atom",
    component: Category,
    layout: "/admin",
    inSidebar: true,    
  },
  {
    path: "/students",
    name: "Students",
    icon: "tim-icons icon-single-02",
    component: Students,
    layout: "/admin",
    inSidebar: true,    
  },
  {
    path: "/icons",
    name: "Icons",
    icon: "tim-icons icon-pin",
    component: Icons,
    layout: "/admin",
    inSidebar: false,
  },
  {
    path: "/notifications",
    name: "Notifications",
    icon: "tim-icons icon-bell-55",
    component: Notifications,
    layout: "/admin",
    inSidebar: false,
  },
  {
    path: "/user-profile",
    name: "User Profile",
    icon: "tim-icons icon-single-02",
    component: UserProfile,
    layout: "/admin",
    inSidebar: false,
  },
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: "tim-icons icon-chart-pie-36",
    component: StudentDashboard,
    layout: "/students",
    inSidebar: true,
  },
  {
    path: "/products",
    name: "Products",
    icon: "tim-icons icon-bell-55",
    component: StudentProducts,
    layout: "/students",
    inSidebar: true,
  },
  {
    path: "/view_product",
    name: "Product",
    icon: "tim-icons icon-bell-55",
    component: ViewProduct,
    layout: "/students",
    inSidebar: false,
  },
  {
    path: "/orders",
    name: "Orders",
    icon: "tim-icons icon-bell-55",
    component: StudentProducts,
    layout: "/students",
    inSidebar: false,
  },
  {
    path: "/user-profile",
    name: "User Profile",
    icon: "tim-icons icon-single-02",
    component: UserProfile,
    layout: "/students",
    inSidebar: false,
  }
];
export default routes;
