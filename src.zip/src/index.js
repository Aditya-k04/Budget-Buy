import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Route, Switch, Redirect } from "react-router-dom";

import AdminLayout from "layouts/Admin/Admin.js";
import StudentsLayout from "layouts/Students/Students.js";
import Login from "views/Login.js";

import "assets/scss/black-dashboard-react.scss";
import "assets/demo/demo.css";
import "assets/css/nucleo-icons.css";
import "assets/css/custom.css";
import "@fortawesome/fontawesome-free/css/all.min.css";

import ThemeContextWrapper from "./components/ThemeWrapper/ThemeWrapper";
import BackgroundColorWrapper from "./components/BackgroundColorWrapper/BackgroundColorWrapper";
import Register from "views/Register.js";
import OrderPlacedSuccess from "views/OrderPlacedSuccess.js";
import AdminLogin from "views/AdminLogin.js";
import Home from "layouts/Home.js";

const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <ThemeContextWrapper>
    <BackgroundColorWrapper>
      <BrowserRouter>
        <Switch>
          <Route path="/students/checkout" render={() => <OrderPlacedSuccess />} />
          <Route exact path="/admin/login" render={() => <AdminLogin />} />    
          <Route path="/admin" render={(props) => <AdminLayout {...props} />} />    
          <Route path="/home" render={() => <Home />} />
          <Route path="/login" render={() => <Login />} />
          <Route path="/register" render={() => <Register />} />
          <Route path="/students" render={(props) => <StudentsLayout {...props} />} />
          <Redirect exact from="/" to="/home" />
          <Redirect exact from="/admin/login" to="/admin/login" />
          <Redirect from="/admin" to="/admin/dashboard" />
          <Redirect from="/students" to="/students/dashboard" />
        </Switch>
      </BrowserRouter>
    </BackgroundColorWrapper>
  </ThemeContextWrapper>
);
