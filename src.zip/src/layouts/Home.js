import React from "react";
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";
import { Button, Card, CardBody, CardFooter, CardHeader, CardSubtitle, CardText, CardTitle, Col, Container, Row } from "reactstrap";

const Home = () => {

    const history = useHistory();

    return (
        <div className="homeFlexWrapper">
            <Container>
                <Row>
                    <Col className="col-12">
                        <Card>
                            <CardHeader>
                                <CardTitle tag="h1" align="center">
                                    Welcome to BudgetBuy 
                                </CardTitle>
                                <CardSubtitle align="center" tag="h4">
                                    Your Student Marketplace!
                                </CardSubtitle>
                            </CardHeader>
                            <CardBody className="col-8" align="center" style={{'margin':"0 auto"}}>
                                <CardText tag="p">
                                    BudgetBuy is the ultimate platform for students to buy and sell goods within their educational community. Whether you're looking for textbooks, electronics, furniture, or any other student essentials, BudgetBuy connects you with fellow students offering quality products at affordable prices.
                                </CardText>
                                <br />
                                <CardText tag="p">
                                    With BudgetBuy, you can browse through a wide range of listings, conveniently manage your own products, and communicate with potential buyers or sellers. Our student verification process ensures a secure and trustworthy environment, giving you peace of mind throughout your transactions.
                                </CardText>
                                <br />
                                <CardText tag="p">
                                    Say goodbye to the hassle of searching for student deals elsewhere. Join BudgetBuy today and experience the convenience and affordability of a dedicated marketplace designed exclusively for students. Start saving money and making connections within your educational community with BudgetBuy.
                                </CardText>
                            </CardBody>
                            <CardFooter align="center">
                                <Button color="warning" onClick={() => history.push("/login")}>
                                    Join Us
                                </Button>
                            </CardFooter>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    );
}

export default Home;